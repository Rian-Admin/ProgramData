function QualityOfBathymetryCoverage(feature, featurePortrayal, contextParameters)
	
	featurePortrayal:AddInstructions('ViewingGroup:13030;DrawingPriority:3;DisplayPlane:UnderRadar;NullInstruction')

end